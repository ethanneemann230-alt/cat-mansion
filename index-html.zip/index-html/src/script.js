// --- PRO STATE MANAGEMENT ---
let db = JSON.parse(localStorage.getItem('infinity_cat_save')) || {
    bucks: 5000,
    inventory: [],
    luck: 1.0,
    pityCounter: 0
};

let pPos = 0, pDir = 1, tL = 35, tW = 22;

// Smooth Animation Engine
function engine() {
    pPos += 3.4 * pDir; // High speed for challenge
    if (pPos >= 100 || pPos <= 0) pDir *= -1;
    document.getElementById('pin').style.left = pPos + '%';
    requestAnimationFrame(engine);
}
engine();

function sync() {
    document.getElementById('m-bucks').innerText = Math.floor(db.bucks);
    document.getElementById('m-cats').innerText = db.inventory.length;
    document.getElementById('target').style.left = tL + '%';
    document.getElementById('target').style.width = tW + '%';
    localStorage.setItem('infinity_cat_save', JSON.stringify(db));
}

// "Haptic" Rescue Logic
function handleRescue() {
    const isHit = pPos >= tL && pPos <= (tL + tW);
    const catEl = document.getElementById('hero-cat');

    if (isHit) {
        db.bucks += 250;
        db.inventory.push({i:'🐱', r: 1});
        tL = Math.random() * 65; // Move target
        
        // Win Animation
        catEl.animate([
            { transform: 'scale(1)', opacity: 1 },
            { transform: 'scale(3) rotate(360deg)', opacity: 0 }
        ], { duration: 500, easing: 'ease-out' });
        
        setTimeout(() => tab('mansion'), 500);
    } else {
        // Lose Shake
        document.getElementById('app').animate([
            { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }
        ], { duration: 50, iterations: 4 });
    }
    sync();
}

// 50x Mega Pack + Pity System
function buyGiga() {
    if (db.bucks < 5000) return alert("RESCUE MORE CATS!");
    db.bucks -= 5000;
    
    for(let i=0; i<50; i++) {
        db.pityCounter++;
        let r = Math.random() * db.luck;
        
        // Pity: Guaranteed Mythic at 150 pulls
        if (r > 0.992 || db.pityCounter >= 150) {
            db.inventory.push({i:'🌌', r: 3});
            db.pityCounter = 0;
        } else if (r > 0.92) {
            db.inventory.push({i:'👑', r: 2});
        } else {
            db.inventory.push({i:'🐱', r: 1});
        }
    }
    sync();
    tab('mansion');
}

// Ethanplaz1133 Creator Logic
function applyCreator() {
    const code = document.getElementById('c-input').value;
    if (code === "Ethanplaz1133") {
        db.luck = 2.85; 
        db.bucks += 10000;
        // Visual Theme Shift
        document.documentElement.style.setProperty('--glow', '#ffae00');
        document.getElementById('app').style.boxShadow = "0 0 60px rgba(255, 174, 0, 0.4)";
        alert("💎 ETHANPLAZ1133 ACTIVE\nLuck X2.8 | +10,000 Meow Bucks");
    }
    sync();
}

function tab(t) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('on'));
    document.getElementById('v-'+t).classList.add('active');
    document.getElementById('n-'+t).classList.add('on');
    if(t === 'mansion') renderMansion();
}

function renderMansion() {
    const m = document.getElementById('mansion');
    m.innerHTML = '';
    // Show last 50 cats to prevent lag
    db.inventory.slice(-50).forEach(cat => {
        const div = document.createElement('div');
        div.className = `cat-vibe rarity-${cat.r}`;
        div.innerText = cat.i;
        div.style.left = Math.random() * 80 + '%';
        div.style.top = Math.random() * 80 + '%';
        m.appendChild(div);
    });
}
// --- ADMIN ENGINE ---
function applyCreator() {
    const code = document.getElementById('c-input').value;
    
    // SECRET UNLOCK
    if (code === "ADMIN_OPEN") {
        document.getElementById('admin-panel').style.display = 'block';
        alert("🔓 ADMIN TERMINAL GRANTED");
        return;
    }

    if (code === "Ethanplaz1133") {
        db.luck = 3; 
        db.bucks += 5000; 
        alert("ETHANPLAZ1133 BOOST ACTIVE!");
    }
    sync();
}

function executeAdmin() {
    const fullCmd = document.getElementById('admin-cmd').value;
    const parts = fullCmd.split(" ");
    const cmd = parts[0].toLowerCase();
    const val = parts[1];

    switch(cmd) {
        case "/money":
            db.bucks += parseInt(val) || 1000000;
            alert("💰 GENERATED " + (val || "1M") + " MEOW BUCKS");
            break;

        case "/luck":
            db.luck = parseFloat(val) || 100;
            alert("🍀 SERVER LUCK SET TO: " + db.luck + "x");
            break;

        case "/spawn":
            const catType = val || "👑";
            for(let i=0; i<10; i++) db.cats.push(catType);
            alert("🐱 SPAWNED 10 " + catType);
            break;

        case "/nuke":
            if(confirm("DELETE EVERYTHING?")) {
                db.cats = [];
                db.bucks = 0;
                db.luck = 1;
                alert("☢️ MANSION DELETED");
            }
            break;

        case "/god":
            db.bucks = Infinity;
            db.luck = 999;
            tW = 100; // Makes the green zone the entire bar
            alert("⚡ GOD MODE ENABLED");
            break;

        default:
            alert("UNKNOWN COMMAND. Try: /money, /luck, /spawn, /nuke, /god");
    }
    sync();
    renderMansion();
}
// --- ENHANCED ADMIN TERMINAL ---
function executeAdmin() {
    const fullCmd = document.getElementById('admin-cmd').value;
    const parts = fullCmd.split(" ");
    const cmd = parts[0].toLowerCase();
    const val = parts.slice(1).join(" "); // Joins everything after the command as text

    switch(cmd) {
        case "/broadcast":
            const banner = document.getElementById('global-announcement');
            const text = document.getElementById('announcement-text');
            banner.style.display = 'block';
            text.innerText = "ADMIN: " + val;
            // Banner stays for 10 seconds then fades
            setTimeout(() => banner.style.display = 'none', 10000);
            break;

        case "/money":
            let amount = parseInt(val) || 1000000;
            db.bucks += amount;
            alert(`💰 INJECTED ${amount} MEOW BUCKS`);
            break;

        case "/luck":
            db.luck = parseFloat(val) || 10;
            alert(`🍀 SERVER-WIDE LUCK MODIFIED TO ${db.luck}x`);
            break;

        case "/event":
            // Spawns a limited-time Mythic Event
            document.getElementById('global-announcement').style.display = 'block';
            document.getElementById('announcement-text').innerText = "✨ MYTHIC EVENT ACTIVE: 5X LUCK! ✨";
            db.luck *= 5;
            document.documentElement.style.setProperty('--glow', 'var(--mythic)');
            break;

        case "/xp":
            // Level up system (if you add levels later)
            alert("SYSTEM: XP COMMANDS ARE COMING IN V5.0");
            break;

        case "/clear":
            document.getElementById('admin-cmd').value = "";
            break;

        case "/god":
            db.bucks = 999999999;
            db.luck = 50;
            tW = 100; // Entire bar is green
            tL = 0;
            alert("⚡ GOD MODE: INFINITE MB & AUTO-WIN ENABLED");
            break;

        default:
            alert("ADMIN_ERROR: CMD NOT FOUND. Commands: /broadcast, /money, /luck, /event, /god, /clear");
    }
    sync();
    renderMansion();
}
case "/testmode":
            db.bucks = 50000;
            db.luck = 2.0;
            alert("🛠️ TESTER MODE: 50k MB & 2x Luck Enabled.");
            sync();
            break;
